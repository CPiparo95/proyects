package com.codeoftheweb.salvo.model;

public enum ShipType {
    gaucho1,
    gaucho2,
    gaucho3,
    gaucho4,
    gaucho5
}
